

var data='result data';

/**
 * this function is executed in the target page, when file is loaded
 */
showResult(data);